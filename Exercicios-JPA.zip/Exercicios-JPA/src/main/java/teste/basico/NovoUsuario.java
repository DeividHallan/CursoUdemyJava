package teste.basico;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import modelo.base.Usuario;

public class NovoUsuario {

	public static void main(String[] args) {

		//Pode-se cricar v�rias conex�es de v�rios banco de dados pelo Manager Factory
		//e cara "emf" ter� o seu "em" exemplo:
//			emf1 - banco legado
//			em1 - criado para o banco legado
//			emf2 - banco oracle
//			em2 - Criado para o banco oracle
//			emf3 - banco SQL
//			em3 - criado para o banco SQL
//			etc...
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Exercicios-JPA");
		EntityManager em = emf.createEntityManager();
		
		Usuario novoUsuario = new Usuario("Teste usuario 5", "user5@user.com.br");
		
		em.getTransaction().begin();
		em.persist(novoUsuario);
		System.out.println("Usu�rio Criado:" + novoUsuario.getNome());
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
}
