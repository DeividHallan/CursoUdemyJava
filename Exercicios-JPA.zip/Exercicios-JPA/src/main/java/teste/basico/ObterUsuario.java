package teste.basico;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import modelo.base.Usuario;

public class ObterUsuario {

	public static void main(String[] args) {
		//Pode-se cricar v�rias conex�es de v�rios banco de dados pelo Manager Factory
		//e cara "emf" ter� o seu "em" exemplo:
//			emf1 - banco legado
//			em1 - criado para o banco legado
//			emf2 - banco oracle
//			em2 - Criado para o banco oracle
//			emf3 - banco SQL
//			em3 - criado para o banco SQL
//			etc...
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Exercicios-JPA");
		EntityManager em = emf.createEntityManager();
		

		Usuario usuario = em.find(Usuario.class, 2L);
		System.out.println("Usu�rio selecionado no sistema: " + usuario.getNome());
		
		em.close();
		emf.close();
	}
}
