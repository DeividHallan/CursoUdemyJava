package teste.basico;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import modelo.base.Usuario;

public class ObterUsuarios {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.
				createEntityManagerFactory("Exercicios-JPA");
		EntityManager em = emf.createEntityManager();
		
		String jqpl = "SELECT u.name FROM usuario u";
//		TypedQuery<Usuario> query = em.createQuery(jqpl, Usuario.class);
//		query.setMaxResults(5);
		

		Query query =  em.createQuery(jqpl);
		List<Usuario> usuarios = query.getResultList();

		
		
		for (Usuario usuario: usuarios) {
			System.out.println("usuarios: " + usuario.getNome());
		}
		
		em.close();
		emf.close();
	}
}